from src.core import PastThreads

PastThreads().get_by_email("ankit03june@gmail.com")
