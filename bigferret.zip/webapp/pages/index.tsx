import { Button, Center } from "@mantine/core";

export default function Home() {
  return (
    <Center m="lg">
      <Button variant="outline">Login with Google</Button>
    </Center>
  );
}
